import { Link } from "react-router-dom";
const Navbar = () => (
    <nav>
        <Link to="/">Customers List</Link>
    </nav>
);
export default Navbar;
