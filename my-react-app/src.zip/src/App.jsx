import { useState } from 'react';
// import List from './components/List';
// import Login from './components/Login';
// import Registration from './components/Registration';
import Container from './components/Container';

function App() {
  
  // const title = "Transflower Student";
  // const [count, setCount] = useState(0);

  // const person = {
  //   firstName: "Rutuja",
  //   lastName: "Tambade",
  //   Email: "rututambade@gmail.com",
  //   contact: "3154284644"
  // };

  // const onButtonClick = () => {
  //   setCount(count + 1);
  //   console.log("Click me button is pressed....." + count);
  // }

  return (
    <>
    {/* <div className='card' style={{ margin: 'auto', padding: '20px', border: '1px solid #ccc', width: '300px', textAlign:'center' }}>
        <p>{title}</p>
        <p>Information: <b>{person.firstName} {person.lastName}</b></p>
        <p>Email: {person.Email}</p>
        <p>Contact: {person.contact}</p>

        <label>Clicks: {count}</label>
        <br />
        <button onClick={onButtonClick}>Click</button>
      </div> */}
      {/* <List></List>
      <Login></Login>
      <Registration></Registration> */}
      <Container></Container>
    </>
  );
}

export default App;
