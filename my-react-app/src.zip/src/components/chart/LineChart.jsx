const LineChart =()=>{
    return( <div>
                <p>Line Chart</p>
                <img src="/images/charts/linechart.jpg" width="200" height="200"/>
            </div>);
}
 
export default LineChart;