const BarChart =()=>{
    return( <div>
                <p>Bar Chart</p>
                <img src="/images/charts/barchart.jpg" width="200" height="200"/>
            </div>);
}
 
export default BarChart;