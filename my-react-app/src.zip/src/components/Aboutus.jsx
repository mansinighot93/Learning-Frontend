function Aboutus() {
    return (
      <div>
        <h1>Transflower Leraning Pvt. Ltd.</h1>
        <p>Chief Mentor: Ravi Tambade</p>
        <p>Founder: Shubhangi Tambade</p>
        <p>Skill based Training Provider Company</p>
      </div>
    );
}

export default Aboutus;