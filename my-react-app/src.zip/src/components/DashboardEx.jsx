import React from 'react'

export const DashboardEx = () => {
  return (
    <div>DashboardEx</div>
  )
}
