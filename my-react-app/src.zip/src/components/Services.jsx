function Services() {
    return (
      <div>
         <h2>Transflower Learning</h2>
         <p>Corporate Trainings</p>
         <p>Project based Learning</p>
         <p>FullStack Developer Roadmap</p>
      </div>
    );
  }
export default Services;