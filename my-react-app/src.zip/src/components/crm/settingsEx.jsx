import React from 'react'

export const settingsEx = () => {
  return (
    <div>settingsEx</div>
  )
}
