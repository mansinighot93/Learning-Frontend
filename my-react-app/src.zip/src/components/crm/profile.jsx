import React from 'react'

export const profile = () => {
  return (
    <div>profile</div>
  )
}
