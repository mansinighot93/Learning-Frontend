import React from 'react'

export const Customerdelete = () => {
  return (
    <div>Customerdelete</div>
  )
}
