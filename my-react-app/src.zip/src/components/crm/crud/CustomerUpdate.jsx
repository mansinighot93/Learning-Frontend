import React from 'react'

export const CustomerUpdate = () => {
  return (
    <div>CustomerUpdate</div>
  )
}
