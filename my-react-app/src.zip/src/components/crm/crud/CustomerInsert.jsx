import React from 'react'

export const CustomerInsert = () => {
  return (
    <div>CustomerInsert</div>
  )
}
